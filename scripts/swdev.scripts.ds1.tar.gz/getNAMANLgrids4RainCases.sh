#!/bin/sh
###############################################################################
#
# getNAMANLgrids4RainCases.sh    Morris/SAIC/GPM GV    Feb 2011
#
# DESCRIPTION:
# Query gpmgv database for dates/times of rainy PR overpasses and assemble
# command string to download NAM Analysis grid subsets for the nearest
# cycle date/time from the NCDC NOMADS archives.  Uses PERL scripts
# get_inv.pl and get_grib.pl provided by NCEP to subset the GRIB files to
# the variables/levels of interest and download the subsetted GRIB files,
# which are then compressed using gzip.  Downloaded files are cataloged in the
# 'gpmgv' database table 'modelgrids'.
#
###############################################################################


GV_BASE_DIR=/home/morris
DATA_DIR=/data/gpmgv
TMP_DIR=${DATA_DIR}/tmp
LOG_DIR=${DATA_DIR}/logs
GRIB_DATA=${DATA_DIR}/GRIB/NAMANL
rundate=`date -u +%y%m%d`
LOG_FILE=${LOG_DIR}/getNAMANLgrids4RainCases.${rundate}.log

echo "Starting NAM Analysis grid acquisition on $rundate." | tee $LOG_FILE
echo "========================================================"\
 | tee -a $LOG_FILE
echo "" | tee -a $LOG_FILE

# re-used file to hold output from database queries
DBTEMPFILE=${TMP_DIR}/getNAMANLdata_dbtempfile
# list of cycle datetimes to retrieve, as URL/file specs
NAMTOGET=${TMP_DIR}/getNAMANLdata_URLtempfile
if [ -f $NAMTOGET ]
  then
    rm -v $NAMTOGET | tee -a $LOG_FILE 2>&1
fi

# find the latest orbit with 2A-5x products available.  Don't want to consider
# orbits beyond this, since rain case metadata will be incomplete for these.

DBOUT=`psql -A -t -d gpmgv -c "select max(orbit) from collatecolswsub a,\
 gvradar f, gvradar c WHERE a.nominal = f.nominal AND a.radar_id = f.radar_id\
 AND f.product = '2A53' and a.nominal = c.nominal AND a.radar_id = c.radar_id\
 AND c.product = '2A54';"`

echo "Latest orbit with 2A-5x data: $DBOUT" | tee -a $LOG_FILE 2>&1
echo "" | tee -a $LOG_FILE

# query finds orbits and times where either of the PR "100 rain certain 4-km gridpoints within 100km"
# or the GR "100 2-km non-zero 2A-53 rainrate gridpoints" criteria are met.  The latter query is much
# more likely to be met for a set of overpassed GR sites.  Excludes orbits whose matching model run
# has already been downloaded/cataloged, and those for which 2A-5x products have not been recieved yet.

echo "\t \a \o $DBTEMPFILE \\\select a.orbit, min(overpass_time at time zone 'UTC')\
 from rainy100inside100 a, orbit_subset_product b where a.orbit=b.orbit and b.product_type='2A12'\
 and a.orbit<${DBOUT}
 and not exists (select * from modelgrids m where b.orbit=m.orbit and model='NAMANL' and filetype='GRIB')\
 group by a.orbit\
 UNION select a.orbit, min(overpass_time at time zone 'UTC') from rainy100by2a53 a,\
 orbit_subset_product b where a.orbit=b.orbit and b.product_type='2A12' and a.orbit<${DBOUT}\
 and not exists (select * from modelgrids m where b.orbit=m.orbit and model='NAMANL' and filetype='GRIB')\
 group by a.orbit order by 1 limit 5;" \
  | psql gpmgv | tee -a $LOG_FILE 2>&1

# cat $DBTEMPFILE
# exit

while read line
  do
    prdatetime=`echo $line`
    orbit=`echo $prdatetime | cut -f1 -d '|'`
    yyyymmdd=`echo $prdatetime | cut -f2 -d '|' | cut -f1 -d ' ' | sed "s/-//g"`
    yyyymm=`echo $yyyymmdd | cut -c1-6`
    hh=`echo $prdatetime | cut -f2 -d ' ' | cut -c1-2`
    echo "" | tee -a $LOG_FILE
    echo "=====================================================================" | tee -a $LOG_FILE
    echo "" | tee -a $LOG_FILE
    echo $prdatetime | tee -a $LOG_FILE
    echo hh: $hh | tee -a $LOG_FILE
    cycle1=`expr $hh + 3`
    cycle2=`expr $cycle1 / 6`
    cycle=`expr $cycle2 \* 6`
    if [ `expr $cycle = 24` = 1 ]
      then
        echo "" | tee -a $LOG_FILE
        echo "Mapping to 00Z cycle of the following day, and incrementing day." | tee -a $LOG_FILE
        echo "" | tee -a $LOG_FILE
        cycle=0
        newyyyymmdd=`offset_date $yyyymmdd 1`
        yyyymmdd=$newyyyymmdd
        yyyymm=`echo $yyyymmdd | cut -c1-6`
    fi
    if [ `expr $cycle \< 10` = 1 ]
      then
        cycle=0$cycle
    fi
    echo yyyymmdd: $yyyymmdd | tee -a $LOG_FILE
    echo yyyymm: $yyyymm | tee -a $LOG_FILE
    echo cycle: $cycle | tee -a $LOG_FILE
    namfile="namanl_218_${yyyymmdd}_${cycle}00_000"
    dbdate=`echo $yyyymmdd | awk '{print substr($1,1,4)"-"substr($1,5,2)"-"substr($1,7,2)}'`
    dbcycle=${cycle}:00:00+00
    echo "${orbit}|${dbdate}|${dbcycle}|${yyyymm}/${yyyymmdd}/${namfile}" \
     | tee -a $NAMTOGET | tee -a $LOG_FILE
done < $DBTEMPFILE

wc $NAMTOGET | tee -a $LOG_FILE


#exit   # uncomment just for testing download set-up


echo "" | tee -a $LOG_FILE
echo "=====================================================================" | tee -a $LOG_FILE
echo "" | tee -a $LOG_FILE

if [ -s $NAMTOGET ]
  then
   # get the date 1 year ago.  NAM archive only goes back 1 year, so get .inv
   # files from NAMANL (NAM) if before (after) this date
    yyyymmddnow=`date -u +%Y%m%d`
    lastyr_yyyymmdd=`offset_date $yyyymmddnow -365`

   # list and acquire the unique model cycles
    for filespec in `cat $NAMTOGET | cut -f4 -d '|' | sort -u`
      do
       # check whether data date is more than 1 year ago; if so then get .inv
       # from namanl, otherwise get from nam archive
        file_yyyymmdd=`echo $filespec | cut -f2 -d'/'`
        echo "lastyr: $lastyr_yyyymmdd    fileyr: $file_yyyymmdd"
        if [ $file_yyyymmdd -gt $lastyr_yyyymmdd ]
          then
           # generate the matching .inv file name for retrieval from the nam achive
           # since the namanl archive has missing .inv files after late-Sep. 2010
            invfilespec=`echo $filespec | sed 's/namanl/nam/'`
            b="http://nomads.ncdc.noaa.gov/data/nam/${invfilespec}"
          else
           # just generate the .inv file name for retrieval from the namanl achive
            b="http://nomads.ncdc.noaa.gov/data/namanl/${filespec}"
        fi
        echo "Using NOMADS inventory file: $b" | tee -a $LOG_FILE
       # generate the output .grb filename prefix
        outfile=`echo $filespec | cut -f3 -d'/'`
        a="http://nomads.ncdc.noaa.gov/data/namanl/${filespec}"
        echo "Using NOMADS GRIB file: $a" | tee -a $LOG_FILE

       # check whether we already have a version of ${outfile}.grb
        havegribfile="n"
        ls ${GRIB_DATA}/${outfile}.grb* > /dev/null 2>&1
        if [ $? = 0  ]
          then
            havegribfile="y"
           # is it gzipped?
            ls ${GRIB_DATA}/${outfile}.grb* | grep '.gz' | grep -v grep > /dev/null 2>&1
            if [ $? = 0 ]
              then
                echo ""
                echo "Already have ${outfile}.grb.gz" | tee -a $LOG_FILE
                echo ""
                dbfile=${outfile}.grb.gz
              else
                echo ""
                echo "Already have ${outfile}.grb" | tee -a $LOG_FILE
                echo ""
                dbfile=${outfile}.grb
            fi
          else
           # try to retrieve the grib file
            get_inv.pl $b.inv | \
            egrep "(:(TMP|RH|UGRD|VGRD):[1-9][0-9]* mb)|TMP:sfc|TSOIL:0-10|SOILW:0-10"  | \
            get_grib.pl $a.grb ${GRIB_DATA}/${outfile}.grb
            if [ -s ${GRIB_DATA}/${outfile}.grb ]
              then
                havegribfile="y"
                echo ""
                echo "finished downloading ${outfile}.grb" | tee -a $LOG_FILE
                echo ""
                gzip -v ${GRIB_DATA}/${outfile}.grb | tee -a $LOG_FILE 2>&1
                if [ $? = 0 ]
                  then
                    dbfile=${outfile}.grb.gz
                  else
                    echo "Error compressing ${outfile}.grb, store as-is." | tee -a $LOG_FILE
                    dbfile=${outfile}.grb
                fi
              else
                echo ""
                echo "ERROR -- File ${outfile}.grb not downloaded!" | tee -a $LOG_FILE
                echo ""
            fi
        fi

        if [ $havegribfile = "y"  ]
          then
           # find the orbit(s) associated to this model cycle, and catalog in DB
            for orbitfile in `grep $filespec $NAMTOGET`
              do
                orbit=`echo $orbitfile | cut -f1 -d '|'`
                dbdate=`echo $orbitfile | cut -f2 -d '|'`
                dbcycle=`echo $orbitfile | cut -f3 -d '|'`
                echo "insert into modelgrids(orbit,cycle,model,filetype,filename) values \
 (${orbit}, '${dbdate} ${dbcycle}', 'NAMANL', 'GRIB', '${dbfile}');" \
 | psql -a gpmgv  | tee -a $LOG_FILE 2>&1
            done
        fi

    done    # for filespec in `cat $NAMTOGET
fi          # [ -s $NAMTOGET ]

exit
