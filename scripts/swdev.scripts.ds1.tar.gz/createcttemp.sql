CREATE TABLE ct_temp (
    orbit integer,
    radname character varying,
    radid character varying,
    overpassdtime timestamp with time zone,
    proximity double precision
);
