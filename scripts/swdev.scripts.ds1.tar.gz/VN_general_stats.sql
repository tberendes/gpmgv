-- latest event case currently defined in the rainy100inside100 table?

select * from rainy100inside100 order by overpass_time desc limit 1;

-- total site overpasses in VN area prior to given date, for 'available' 88Ds

select count(*) from overpass_event where overpass_time between '2006-07-23 00:00:00-00' and '2011-02-16 23:59:59-00' and radar_id not in ('RMOR','DARW', 'RGSN','KWAJ','KMXX');

-- total rainy cases identified in rainy100inside100, for 'available' 88Ds

select count(*) from rainy100inside100 where radar_id not in ('RMOR','DARW', 'RGSN','KWAJ','KMXX');

-- find 100in100 overpasses having matching 2A55/2A54 radar data (from TRMM GV)
-- DO NOT EXECUTE, KILLER QUERY using collatedproductsWsub

--select count(*) from collatedproductsWsub a, rainy100inside100 b where a.radar_id=b.radar_id and a.orbit=b.orbit and a.file2a55 is not null and a.file2a54 is not null and a.radar_id not in ('RMOR','DARW', 'RGSN','KWAJ');

-- find 100in100 overpasses having matching 1CUF radar data (from TRMM GV)
-- have to exclude duplicate subset matches for KMLB by specifying subset

select count(*) from collatedgvproducts a, rainy100inside100 b where b.overpass_time between '2006-07-23 00:00:00-00' and '2011-02-16 23:59:59-00' and a.radar_id=b.radar_id and a.orbit=b.orbit and a.file1cuf is not null and a.radar_id not in ('RMOR','DARW', 'RGSN','KWAJ') and a.subset='sub-GPMGV1';
